module DataTypes where

type Case = String
type SolvedCase = String
